import math
import time

import cv2
import mediapipe as mp
import numpy as np
import rclpy

from geometry_msgs.msg import PoseArray, Pose
from rclpy.node import Node
from std_msgs.msg import Bool


class HandTeleopNode(Node):

    def __init__(self):

        super().__init__("hand_teleop_node")

        self.pose_pub = self.create_publisher(
            PoseArray,
            "/dual_arm/target_pose",
            10
        )

        self.left_gripper_pub = self.create_publisher(
            Bool,
            "/dual_arm/left_gripper",
            10
        )

        self.right_gripper_pub = self.create_publisher(
            Bool,
            "/dual_arm/right_gripper",
            10
        )

        self.cap = cv2.VideoCapture(0)

        self.mp_hands = mp.solutions.hands

        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            model_complexity=1,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.6
        )

        self.drawer = mp.solutions.drawing_utils

        self.workspace_x = 0.55
        self.workspace_y = 0.55
        self.workspace_z = 0.4

        self.left_offset = np.array(
            [-0.35, 0.18, 0.0]
        )

        self.right_offset = np.array(
            [0.35, -0.18, 0.0]
        )

        self.alpha = 0.25

        self.prev_left = None
        self.prev_right = None

        self.last_seen = time.time()

        self.timer = self.create_timer(
            1.0 / 15.0,
            self.tick
        )

        self.get_logger().info(
            "Dual MediaPipe teleop started"
        )

    def tick(self):

        ok, frame = self.cap.read()

        if not ok:
            return

        rgb = cv2.cvtColor(
            frame,
            cv2.COLOR_BGR2RGB
        )

        results = self.hands.process(rgb)

        left_pose = None
        right_pose = None

        left_closed = False
        right_closed = False

        if results.multi_hand_landmarks:

            handedness = results.multi_handedness

            for hand_landmarks, hand_label in zip(
                results.multi_hand_landmarks,
                handedness
            ):

                label = hand_label.classification[0].label

                pose, pinch = self.compute_pose(
                    hand_landmarks,
                    frame
                )

                self.drawer.draw_landmarks(
                    frame,
                    hand_landmarks,
                    self.mp_hands.HAND_CONNECTIONS
                )

                if label == "Left":

                    left_pose = self.smooth(
                        pose,
                        "left"
                    )

                    left_closed = pinch < 0.05

                else:

                    right_pose = self.smooth(
                        pose,
                        "right"
                    )

                    right_closed = pinch < 0.05

        if left_pose is not None and right_pose is not None:

            msg = PoseArray()

            msg.header.frame_id = "world"

            msg.header.stamp = (
                self.get_clock()
                .now()
                .to_msg()
            )

            msg.poses = [
                left_pose,
                right_pose
            ]

            self.pose_pub.publish(msg)

        self.publish_gripper(
            self.left_gripper_pub,
            left_closed
        )

        self.publish_gripper(
            self.right_gripper_pub,
            right_closed
        )

        cv2.imshow(
            "dual_hand_teleop",
            frame
        )

        cv2.waitKey(1)

    def compute_pose(
        self,
        hand,
        frame
    ):

        h, w, _ = frame.shape

        wrist = hand.landmark[0]

        index = hand.landmark[5]

        thumb_tip = hand.landmark[4]

        index_tip = hand.landmark[8]

        cx = wrist.x
        cy = wrist.y

        x = (
            cx - 0.5
        ) * self.workspace_x

        y = (
            cy - 0.5
        ) * self.workspace_y

        dx = index.x - wrist.x

        dy = index.y - wrist.y

        yaw = math.atan2(
            dy,
            dx
        )

        pinch = math.sqrt(

            (
                thumb_tip.x
                - index_tip.x
            )**2

            +

            (
                thumb_tip.y
                - index_tip.y
            )**2
        )

        pose = Pose()

        pose.position.x = float(x)

        pose.position.y = float(-y)

        pose.position.z = self.workspace_z

        half = yaw / 2.0

        pose.orientation.z = math.sin(
            half
        )

        pose.orientation.w = math.cos(
            half
        )

        return pose, pinch

    def smooth(
        self,
        pose,
        side
    ):

        prev = (
            self.prev_left
            if side == "left"
            else self.prev_right
        )

        if prev is None:

            if side == "left":
                self.prev_left = pose
            else:
                self.prev_right = pose

            return pose

        alpha = self.alpha

        out = Pose()

        out.position.x = (
            (1-alpha)
            * prev.position.x
            +
            alpha
            * pose.position.x
        )

        out.position.y = (
            (1-alpha)
            * prev.position.y
            +
            alpha
            * pose.position.y
        )

        out.position.z = pose.position.z

        out.orientation = pose.orientation

        if side == "left":
            self.prev_left = out
        else:
            self.prev_right = out

        return out

    def publish_gripper(
        self,
        pub,
        closed
    ):

        msg = Bool()

        msg.data = closed

        pub.publish(msg)


def main():

    rclpy.init()

    node = HandTeleopNode()

    rclpy.spin(node)

    node.destroy_node()

    rclpy.shutdown()


if __name__ == "__main__":
    main()