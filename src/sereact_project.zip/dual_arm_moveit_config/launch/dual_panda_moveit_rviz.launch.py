from launch import LaunchDescription

from launch_ros.actions import Node

from launch_ros.parameter_descriptions import ParameterValue

from launch_ros.substitutions import FindPackageShare

from launch.substitutions import (
    Command,
    PathJoinSubstitution,
)


def generate_launch_description():

    description_package = FindPackageShare(
        "dual_arm_description"
    )

    moveit_package = FindPackageShare(
        "dual_arm_moveit_config"
    )

    robot_description_content = Command(
        [
            "xacro ",
            PathJoinSubstitution(
                [
                    description_package,
                    "urdf",
                    "dual_panda.urdf.xacro",
                ]
            ),
        ]
    )

    robot_description = {
        "robot_description": ParameterValue(
            robot_description_content,
            value_type=str,
        )
    }

    robot_description_semantic_content = Command(
        [
            "xacro ",
            PathJoinSubstitution(
                [
                    moveit_package,
                    "config",
                    "dual_panda.srdf.xacro",
                ]
            ),
        ]
    )

    robot_description_semantic = {
        "robot_description_semantic": ParameterValue(
            robot_description_semantic_content,
            value_type=str,
        )
    }

    kinematics_yaml = PathJoinSubstitution(
        [
            moveit_package,
            "config",
            "kinematics.yaml",
        ]
    )

    joint_limits_yaml = PathJoinSubstitution(
        [
            moveit_package,
            "config",
            "joint_limits.yaml",
        ]
    )

    ompl_planning_yaml = PathJoinSubstitution(
        [
            moveit_package,
            "config",
            "ompl_planning.yaml",
        ]
    )

    moveit_controllers_yaml = PathJoinSubstitution(
        [
            moveit_package,
            "config",
            "moveit_controllers.yaml",
        ]
    )
    servo_yaml = PathJoinSubstitution(
    [moveit_package, "config", "servo.yaml"]
   )

    servo_yaml = PathJoinSubstitution(
        [
            moveit_package,
            "config",
            "servo.yaml",
        ]
    )

    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        output="screen",
        parameters=[
            robot_description
        ],
    )

    joint_state_publisher = Node(
        package="joint_state_publisher",
        executable="joint_state_publisher",
        output="screen",
    )

    move_group = Node(
        package="moveit_ros_move_group",
        executable="move_group",
        output="screen",

        parameters=[
            robot_description,
            robot_description_semantic,
            kinematics_yaml,
            joint_limits_yaml,
            ompl_planning_yaml,
            moveit_controllers_yaml,
        ],
    )
    servo_node = Node(
    package="moveit_servo",

    executable="servo_node_main",

    output="screen",

    parameters=[
        robot_description,
        robot_description_semantic,
        kinematics_yaml,
        servo_yaml,
    ],
)

    servo_node = Node(
        package="moveit_servo",

        executable="servo_node_main",

        output="screen",

        parameters=[
            robot_description,
            robot_description_semantic,
            kinematics_yaml,
            servo_yaml,
        ],
    )

    rviz_config = PathJoinSubstitution(
        [
            moveit_package,
            "rviz",
            "dual_panda_moveit.rviz",
        ]
    )

    rviz = Node(
        package="rviz2",

        executable="rviz2",

        name="rviz2",

        output="screen",

        arguments=[
            "-d",
            rviz_config,
        ],

        parameters=[
            robot_description,
            robot_description_semantic,
        ],
    )

    return LaunchDescription(
        [
            
        robot_state_publisher,
        joint_state_publisher,
        move_group,
        servo_node,
        rviz,
        ]
    )